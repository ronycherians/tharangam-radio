// Caches the app shell so it opens instantly and works offline.
// Only same-origin files are handled: audio streams are never touched
// (intercepting a live stream would break playback).
const VERSION = "th-v1";
const SHELL = [
  "./", "index.html", "css/app.css", "js/app.js", "js/config.js", "manifest.webmanifest",
  "vendor/maplibre-gl.js", "vendor/maplibre-gl.css", "vendor/hls.light.min.js",
  "vendor/anek-malayalam-latin-standard-normal.woff2", "vendor/anek-malayalam-malayalam-standard-normal.woff2",
  "assets/world.json", "icons/icon-192.png", "icons/icon-512.png", "icons/icon.svg",
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin) return;
  if (url.pathname.includes("/data/")) {
    // station list: always try the network first so users get the latest checked list
    e.respondWith(fetch(e.request).then((r) => {
      const copy = r.clone(); caches.open(VERSION).then((c) => c.put(e.request, copy)); return r;
    }).catch(() => caches.match(e.request)));
    return;
  }
  // app shell: cache first, refresh in background
  e.respondWith(caches.match(e.request).then((hit) => {
    const net = fetch(e.request).then((r) => {
      if (r.ok) { const copy = r.clone(); caches.open(VERSION).then((c) => c.put(e.request, copy)); }
      return r;
    }).catch(() => hit);
    return hit || net;
  }));
});
