/* Tharangam Radio - web + Android app (same code; Capacitor wraps it for Android). */
const CFG = window.THARANGAM_CONFIG;
const IS_NATIVE = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
const NativeMedia = IS_NATIVE ? window.Capacitor.Plugins?.MediaSession : null;
const $ = (s) => document.querySelector(s);

/* ------------------------------------------------------------------ text */
const STR = {
  en: {
    search: "Search", saved: "Saved", recent: "Recent", settings: "Settings",
    random: "Surprise me", nearMe: "Near me", hint: "Spin the globe to find a place",
    searchPlaceholder: "Station, city, country or genre",
    stations: (n) => (n === 1 ? "1 station" : `${n.toLocaleString()} stations`),
    connecting: "Connecting…", buffering: "Buffering…", live: "Live", paused: "Paused",
    cantConnect: (n) => `Couldn't connect to ${n}. The station may be off air right now.`,
    nextStation: "Next station", noResults: "No stations match that. Try a city, country or genre.",
    emptySaved: "Tap the heart next to a station to keep it here.",
    emptyRecent: "Stations you listen to will show up here.",
    typeToSearch: "Type a station, city, country, language or genre.",
    offlineNow: "Off air right now", language: "Language",
    autoplay: "Play when the globe stops on a place", sleep: "Sleep timer", off: "Off",
    volume: "Volume", share: "Share this station", website: "Station website", done: "Done",
    tapToPlay: "Tap play to start listening", loading: "Tuning in…",
    loadFailed: "Couldn't load the station list. Check your internet connection, then try again.",
    retry: "Try again", saved1: "Saved", removed1: "Removed from saved",
    sleepSet: (m) => `Radio will stop in ${m} minutes`, sleepDone: "Sleep timer finished",
    linkCopied: "Link copied", noLocation: "Couldn't get your location. Allow location access and try again.",
    about: (n, when) => `${n.toLocaleString()} stations. Every station is checked twice a day; the last check was ${when}.`,
    appOnly: (n) => ` ${n.toLocaleString()} more stations play in the Android app.`,
    ago: (h) => (h < 1 ? "less than an hour ago" : h < 24 ? `${h} hours ago` : `${Math.round(h / 24)} days ago`),
    unknownPlace: "Somewhere",
  },
  ml: {
    search: "തിരയുക", saved: "പ്രിയപ്പെട്ടവ", recent: "അടുത്തിടെ", settings: "ക്രമീകരണങ്ങൾ",
    random: "ഏതെങ്കിലും ഒന്ന്", nearMe: "എന്റെ അടുത്ത്", hint: "ഗ്ലോബ് തിരിച്ച് ഒരു സ്ഥലം കണ്ടെത്തൂ",
    searchPlaceholder: "സ്റ്റേഷൻ, നഗരം, രാജ്യം അല്ലെങ്കിൽ ഇനം",
    stations: (n) => `${n.toLocaleString()} സ്റ്റേഷനുകൾ`,
    connecting: "കണക്റ്റ് ചെയ്യുന്നു…", buffering: "ബഫർ ചെയ്യുന്നു…", live: "തത്സമയം", paused: "നിർത്തി",
    cantConnect: (n) => `${n} ലേക്ക് കണക്റ്റ് ചെയ്യാനായില്ല. സ്റ്റേഷൻ ഇപ്പോൾ ഓഫ് എയർ ആയിരിക്കാം.`,
    nextStation: "അടുത്ത സ്റ്റേഷൻ", noResults: "ഒന്നും കണ്ടെത്തിയില്ല. ഒരു നഗരമോ രാജ്യമോ ഇനമോ നോക്കൂ.",
    emptySaved: "സ്റ്റേഷന്റെ അടുത്തുള്ള ഹൃദയ ചിഹ്നം അമർത്തിയാൽ അത് ഇവിടെ സൂക്ഷിക്കാം.",
    emptyRecent: "നിങ്ങൾ കേൾക്കുന്ന സ്റ്റേഷനുകൾ ഇവിടെ കാണാം.",
    typeToSearch: "സ്റ്റേഷൻ, നഗരം, രാജ്യം, ഭാഷ അല്ലെങ്കിൽ ഇനം ടൈപ്പ് ചെയ്യൂ.",
    offlineNow: "ഇപ്പോൾ ലഭ്യമല്ല", language: "ഭാഷ",
    autoplay: "ഗ്ലോബ് നിൽക്കുന്ന സ്ഥലത്തെ റേഡിയോ തനിയെ പ്ലേ ചെയ്യുക", sleep: "സ്ലീപ് ടൈമർ", off: "ഓഫ്",
    volume: "ശബ്ദം", share: "ഈ സ്റ്റേഷൻ പങ്കിടുക", website: "സ്റ്റേഷന്റെ വെബ്സൈറ്റ്", done: "ശരി",
    tapToPlay: "കേൾക്കാൻ പ്ലേ അമർത്തൂ", loading: "ട്യൂൺ ചെയ്യുന്നു…",
    loadFailed: "സ്റ്റേഷൻ ലിസ്റ്റ് ലോഡ് ചെയ്യാനായില്ല. ഇന്റർനെറ്റ് കണക്ഷൻ പരിശോധിച്ച് വീണ്ടും ശ്രമിക്കൂ.",
    retry: "വീണ്ടും ശ്രമിക്കുക", saved1: "സൂക്ഷിച്ചു", removed1: "പ്രിയപ്പെട്ടവയിൽ നിന്ന് മാറ്റി",
    sleepSet: (m) => `${m} മിനിറ്റിനുള്ളിൽ റേഡിയോ നിൽക്കും`, sleepDone: "സ്ലീപ് ടൈമർ പൂർത്തിയായി",
    linkCopied: "ലിങ്ക് കോപ്പി ചെയ്തു", noLocation: "ലൊക്കേഷൻ ലഭിച്ചില്ല. ലൊക്കേഷൻ അനുമതി നൽകി വീണ്ടും ശ്രമിക്കൂ.",
    about: (n, when) => `${n.toLocaleString()} സ്റ്റേഷനുകൾ. എല്ലാ സ്റ്റേഷനുകളും ദിവസം രണ്ടു തവണ പരിശോധിക്കുന്നു; അവസാന പരിശോധന ${when}.`,
    appOnly: (n) => ` ${n.toLocaleString()} സ്റ്റേഷനുകൾ കൂടി ആൻഡ്രോയിഡ് ആപ്പിൽ കേൾക്കാം.`,
    ago: (h) => (h < 1 ? "ഒരു മണിക്കൂറിനുള്ളിൽ" : h < 24 ? `${h} മണിക്കൂർ മുമ്പ്` : `${Math.round(h / 24)} ദിവസം മുമ്പ്`),
    unknownPlace: "എവിടെയോ",
  },
};

/* --------------------------------------------------------------- storage */
const store = {
  get(k, d) { try { const v = localStorage.getItem("th." + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("th." + k, JSON.stringify(v)); } catch { /* private mode */ } },
};
const settings = Object.assign(
  { lang: (navigator.language || "").startsWith("ml") ? "ml" : "en", autoplay: true, volume: 1 },
  store.get("settings", {}),
);
const saveSettings = () => store.set("settings", settings);
let favs = store.get("favs", []);       // [{id, name, place}] snapshots so offline favourites still show
let recents = store.get("recent", []);

function t(key, ...args) {
  const v = (STR[settings.lang] || STR.en)[key] ?? STR.en[key];
  return typeof v === "function" ? v(...args) : v;
}
function applyI18n() {
  document.documentElement.lang = settings.lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-title]").forEach((el) => {
    el.title = t(el.dataset.i18nTitle); el.setAttribute("aria-label", t(el.dataset.i18nTitle));
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => { el.placeholder = t(el.dataset.i18nPlaceholder); });
}

/* --------------------------------------------------------------- helpers */
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const safeUrl = (u) => (/^https?:\/\//i.test(u || "") ? u : "");
const norm = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
const initials = (name) => (String(name || "?").replace(/[^\p{L}\p{N} ]/gu, "").trim().split(/\s+/).slice(0, 2).map((w) => [...w][0] || "").join("") || "♪").toUpperCase();
let toastTimer;
function toast(msg) {
  const el = $("#toast"); el.textContent = msg; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
async function fetchJSON(url, ms = 15000) {
  const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(url, { signal: ctl.signal, cache: "no-cache" });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } finally { clearTimeout(timer); }
}
function haversine(a, b) {
  const R = 6371, d2r = Math.PI / 180;
  const dLat = (b.lat - a.lat) * d2r, dLon = (b.lon - a.lon) * d2r;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * d2r) * Math.cos(b.lat * d2r) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}

/* ------------------------------------------------------------------ data */
let STATIONS = [];            // playable on this platform
const BY_ID = new Map();
let PLACES = [];
const PLACE_BY_ID = new Map();
let META = { generated: null, appOnly: 0 };

function playUrls(s) {
  // https pages can't play http streams (mixed content). The Android app can.
  const list = IS_NATIVE ? [s.https, s.url]
    : location.protocol === "https:" ? [s.https]
      : [s.url, s.https];
  return [...new Set(list.filter(Boolean))];
}

async function loadData() {
  const sources = IS_NATIVE ? [CFG.remoteDataUrl, CFG.dataUrl] : [CFG.dataUrl];
  let json, lastErr;
  for (const src of sources) {
    try { json = await fetchJSON(src); break; } catch (e) { lastErr = e; console.warn("station list failed:", src, e); }
  }
  if (!json) throw lastErr || new Error("no data");
  const F = json.fields; const ix = Object.fromEntries(F.map((f, i) => [f, i]));
  let appOnly = 0;
  for (const r of json.stations) {
    const s = {
      id: r[ix.id], name: r[ix.name], url: r[ix.url], https: r[ix.https], lat: r[ix.lat], lon: r[ix.lon],
      cc: r[ix.cc], country: r[ix.country], city: r[ix.city], tags: r[ix.tags] || "", codec: r[ix.codec],
      bitrate: r[ix.bitrate], favicon: safeUrl(r[ix.favicon]), homepage: safeUrl(r[ix.homepage]),
      hls: !!r[ix.hls], lang: r[ix.lang] || "", featured: !!r[ix.featured],
    };
    if (!playUrls(s).length) { appOnly++; continue; }
    s._q = norm(`${s.name} ${s.city} ${s.country} ${s.tags} ${s.lang}`);
    s._n = norm(s.name);
    STATIONS.push(s); BY_ID.set(s.id, s);
  }
  META = { generated: json.generated, appOnly };
  buildPlaces();
}

function buildPlaces() {
  const groups = new Map();
  for (const s of STATIONS) {
    const key = `${s.cc}|${Math.round(s.lat * 10)}|${Math.round(s.lon * 10)}`;
    let p = groups.get(key);
    if (!p) { p = { id: groups.size + 1, key, lat: s.lat, lon: s.lon, cc: s.cc, country: s.country, stations: [], _cities: {} }; groups.set(key, p); }
    p.stations.push(s);
    if (s.city) p._cities[s.city] = (p._cities[s.city] || 0) + 1;
    s.place = p;
  }
  PLACES = [...groups.values()];
  for (const p of PLACES) {
    const top = Object.entries(p._cities).sort((a, b) => b[1] - a[1])[0];
    p.name = top ? top[0] : (p.country || t("unknownPlace"));
    p.stations.sort((a, b) => (b.featured - a.featured));   // keeps popularity order otherwise
    PLACE_BY_ID.set(p.id, p);
    delete p._cities;
  }
}
const placeLabel = (s) => [s.city || s.place?.name, s.country].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).join(", ");

/* ------------------------------------------------------------------- map */
let map;
const LAMP = "#F2B544", PEARL = "#EEF2F6";

function mapStyle() {
  const style = {
    version: 8,
    projection: { type: "globe" },
    sky: { "atmosphere-blend": ["interpolate", ["linear"], ["zoom"], 0, 1, 4, 0.6, 6, 0] },
    sources: {
      world: { type: "geojson", data: "assets/world.json", attribution: "Natural Earth" },
      places: { type: "geojson", data: { type: "FeatureCollection", features: [] }, promoteId: "pid" },
    },
    layers: [
      { id: "ocean", type: "background", paint: { "background-color": "#0C1A2B" } },
      { id: "land", type: "fill", source: "world", filter: ["==", ["get", "k"], "land"], paint: { "fill-color": "#1B2C42" } },
      { id: "borders", type: "line", source: "world", filter: ["==", ["get", "k"], "border"],
        paint: { "line-color": "rgba(143,163,188,.28)", "line-width": ["interpolate", ["linear"], ["zoom"], 1, 0.4, 6, 1] } },
    ],
  };
  if (CFG.detailTiles) {
    style.glyphs = "https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf";
    style.sources.detail = { type: "vector", url: "https://tiles.openfreemap.org/planet",
      attribution: '<a href="https://openfreemap.org" target="_blank" rel="noopener">OpenFreeMap</a> © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>' };
    style.layers.push(
      { id: "d-water", type: "fill", source: "detail", "source-layer": "water", minzoom: 4.5, paint: { "fill-color": "#0C1A2B" } },
      { id: "d-admin", type: "line", source: "detail", "source-layer": "boundary", minzoom: 4,
        filter: ["all", ["==", ["get", "admin_level"], 4], ["!=", ["get", "maritime"], 1]],
        paint: { "line-color": "rgba(143,163,188,.18)", "line-dasharray": [2, 2], "line-width": 0.7 } },
      { id: "d-places", type: "symbol", source: "detail", "source-layer": "place", minzoom: 5,
        filter: ["in", ["get", "class"], ["literal", ["city", "town"]]],
        layout: { "text-field": ["coalesce", ["get", "name:en"], ["get", "name:latin"], ["get", "name"]],
          "text-font": ["Noto Sans Regular"], "text-size": 11, "text-offset": [0, 1.1], "text-anchor": "top" },
        paint: { "text-color": "rgba(143,163,188,.75)", "text-halo-color": "#0C1A2B", "text-halo-width": 1.2 } },
    );
  }
  style.layers.push(
    { id: "places-glow", type: "circle", source: "places",
      paint: {
        "circle-color": LAMP, "circle-blur": 1, "circle-opacity": 0.35,
        "circle-radius": ["interpolate", ["linear"], ["zoom"],
          1, ["+", 3, ["*", 1.2, ["sqrt", ["get", "n"]]]],
          6, ["+", 8, ["*", 2.4, ["sqrt", ["get", "n"]]]]],
      } },
    { id: "places-core", type: "circle", source: "places",
      paint: {
        "circle-color": ["case", ["boolean", ["feature-state", "sel"], false], PEARL, LAMP],
        "circle-radius": ["interpolate", ["linear"], ["zoom"], 1, ["case", ["boolean", ["feature-state", "sel"], false], 3.5, 1.6], 6, ["case", ["boolean", ["feature-state", "sel"], false], 6, 3.5]],
        "circle-stroke-width": ["case", ["boolean", ["feature-state", "sel"], false], 2, 0],
        "circle-stroke-color": LAMP,
      } },
  );
  return style;
}

function initMap(start) {
  map = new maplibregl.Map({
    container: "map", style: mapStyle(), center: [start.lon, start.lat], zoom: start.zoom,
    minZoom: 1, maxZoom: 11, maxPitch: 0, dragRotate: false, pitchWithRotate: false,
    attributionControl: { compact: true },
  });
  map.touchZoomRotate.disableRotation();
  map.on("error", (e) => {
    // Detail tiles/glyphs are optional; the bundled globe keeps working without them.
    const src = e?.sourceId || e?.source?.id || "";
    if (src === "detail" || /openfreemap/.test(String(e?.error?.url || e?.error?.message || ""))) return;
    console.warn("map:", e?.error || e);
  });
  return new Promise((resolve) => map.on("load", () => {
    map.getSource("places").setData({
      type: "FeatureCollection",
      features: PLACES.map((p) => ({ type: "Feature", geometry: { type: "Point", coordinates: [p.lon, p.lat] }, properties: { pid: p.id, n: p.stations.length } })),
    });
    map.on("move", onMove);
    map.on("moveend", onMoveEnd);
    map.on("click", "places-glow", onDotClick);
    map.on("click", "places-core", onDotClick);
    map.on("mouseenter", "places-glow", () => { map.getCanvas().style.cursor = "pointer"; });
    map.on("mouseleave", "places-glow", () => { map.getCanvas().style.cursor = ""; });
    resolve();
  }));
}

function reticlePoint() {
  const c = map.getContainer(), pad = map.getPadding();
  return { x: pad.left + (c.clientWidth - pad.left - pad.right) / 2, y: pad.top + (c.clientHeight - pad.top - pad.bottom) / 2 };
}
function placeUnderReticle() {
  const p = reticlePoint(), R = 30;
  const feats = map.queryRenderedFeatures([[p.x - R, p.y - R], [p.x + R, p.y + R]], { layers: ["places-core", "places-glow"] });
  let best = null, bestD = Infinity;
  for (const f of feats) {
    const pl = PLACE_BY_ID.get(f.properties.pid); if (!pl) continue;
    const q = map.project([pl.lon, pl.lat]); const d = Math.hypot(q.x - p.x, q.y - p.y);
    if (d < bestD && d <= R) { bestD = d; best = pl; }
  }
  return best;
}

let hovered = null, moveRaf = 0, userMoving = false;
function onMove(e) {
  if (e.originalEvent) userMoving = true;
  if (moveRaf) return;
  moveRaf = requestAnimationFrame(() => {
    moveRaf = 0;
    hovered = placeUnderReticle();
    document.body.classList.toggle("locked", !!hovered);
    $("#reticle-label").textContent = hovered ? hovered.name : "";
  });
}
function onMoveEnd() {
  hovered = placeUnderReticle();
  document.body.classList.toggle("locked", !!hovered);
  $("#reticle-label").textContent = hovered ? hovered.name : "";
  const byUser = userMoving; userMoving = false;
  if (!hovered || hovered === currentPlace) return;
  selectPlace(hovered);
  const alreadyHere = current && current.place === hovered;
  if (byUser && settings.autoplay && audioUnlocked && !alreadyHere) play(hovered.stations[0]);
}
function onDotClick(e) {
  const f = e.features && e.features[0]; if (!f) return;
  const p = PLACE_BY_ID.get(f.properties.pid); if (!p) return;
  userMoving = true;   // treat as a deliberate tune
  map.easeTo({ center: [p.lon, p.lat], duration: 650 });
}
function flyToPlace(p, zoom) {
  map.flyTo({ center: [p.lon, p.lat], zoom: zoom ?? Math.max(map.getZoom(), 4), speed: 1.4, essential: true });
}

/* ------------------------------------------------------------ the sheet */
let currentPlace = null;
let selectedFeature = null;
function selectPlace(p) {
  currentPlace = p;
  if (selectedFeature != null) map.setFeatureState({ source: "places", id: selectedFeature }, { sel: false });
  map.setFeatureState({ source: "places", id: p.id }, { sel: true });
  selectedFeature = p.id;
  $("#place-name").removeAttribute("data-i18n");
  $("#place-name").textContent = p.name;
  $("#place-sub").textContent = [p.name !== p.country ? p.country : "", t("stations", p.stations.length)].filter(Boolean).join(", ");
  renderList($("#place-list"), p.stations, { showPlace: false });
  $("#place-list").scrollTop = 0;
  layout();
}

function artInner(s) {
  const img = s.favicon ? `<img src="${esc(s.favicon)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">` : "";
  return `${esc(initials(s.name))}${img}`;
}
const artHTML = (s, cls) => `<span class="${cls}" aria-hidden="true">${artInner(s)}</span>`;
const HEART = '<svg viewBox="0 0 24 24"><path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7a4.3 4.3 0 0 1 7.5 2.8C19.5 15.4 12 20 12 20Z"/></svg>';

function renderList(ul, items, { showPlace = true, emptyText = "" } = {}) {
  if (!items.length) { ul.innerHTML = emptyText ? `<li class="empty">${esc(emptyText)}</li>` : ""; return; }
  ul.innerHTML = items.map((it) => {
    const s = BY_ID.get(it.id) || it;            // snapshot if it's no longer online
    const online = BY_ID.has(it.id);
    const meta = !online ? t("offlineNow")
      : [showPlace ? placeLabel(s) : "", s.tags.split(",").slice(0, 3).join(", ")].filter(Boolean).join(" · ");
    const fav = isFav(s.id);
    return `<li data-id="${esc(s.id)}" class="${online ? "" : "offline"} ${current && current.id === s.id ? "current" : ""}">
      ${artHTML(s, "st-art")}
      <span class="st-text"><span class="st-name">${esc(s.name)}</span><span class="st-meta">${esc(meta)}</span></span>
      <button class="st-fav" aria-label="${esc(t("saved"))}" aria-pressed="${fav}">${HEART}</button></li>`;
  }).join("");
}
function onListClick(e) {
  const li = e.target.closest("li[data-id]"); if (!li) return;
  const id = li.dataset.id;
  if (e.target.closest(".st-fav")) { toggleFav(BY_ID.get(id) || favs.find((f) => f.id === id)); return; }
  const s = BY_ID.get(id); if (!s) return;
  if (current && current.id === id && state === "playing") return;
  play(s);
  if (li.closest("#results")) { closeDrawer(); selectPlace(s.place); flyToPlace(s.place); }
}

let sheetPeek = 210;
function layout() {
  const desktop = matchMedia("(min-width: 900px)").matches;
  const sheet = $("#sheet");
  if (desktop) {
    map && map.setPadding({ left: sheet.offsetWidth + 16, bottom: 0, top: 0, right: 0 });
    document.documentElement.style.removeProperty("--reticle-y");
    return;
  }
  const player = $("#player"), err = $("#np-error"), head = $(".place-head");
  const firstRow = $("#place-list li");
  sheetPeek = 22 + (player.hidden ? 0 : player.offsetHeight) + (err.hidden ? 0 : err.offsetHeight + 12)
    + head.offsetHeight + (firstRow ? Math.min(firstRow.offsetHeight * 1.4, 84) : 12);
  sheetPeek = Math.min(sheetPeek, window.innerHeight * 0.5);
  document.documentElement.style.setProperty("--sheet-peek", `${Math.round(sheetPeek)}px`);
  const topPad = 64;
  map && map.setPadding({ left: 0, right: 0, top: topPad, bottom: sheetPeek });
  document.documentElement.style.setProperty("--reticle-y", `${Math.round(topPad + (window.innerHeight - topPad - sheetPeek) / 2)}px`);
}
function toggleSheet(force) {
  const s = $("#sheet");
  const collapse = force !== undefined ? force : !s.classList.contains("collapsed");
  s.classList.toggle("collapsed", collapse);
  $("#grabber").setAttribute("aria-label", collapse ? "Expand station list" : "Collapse station list");
}

/* ---------------------------------------------------------------- player */
const audio = $("#audio");
let current = null, state = "idle", token = 0, hls = null, connectTimer = null, audioUnlocked = false, urls = [], urlIndex = 0;

function setState(next, detail) {
  state = next;
  document.body.classList.toggle("playing", next === "playing");
  document.body.classList.toggle("loading", next === "loading");
  const label = { loading: detail || t("connecting"), playing: `${t("live")} · ${current ? placeLabel(current) : ""}`, paused: current ? placeLabel(current) : "", error: "" }[next] ?? "";
  $("#np-status").textContent = label;
  $("#np-play").setAttribute("aria-label", next === "playing" || next === "loading" ? "Pause" : "Play");
  $("#np-error").hidden = next !== "error";
  if (next === "error") $("#np-error-text").textContent = t("cantConnect", current.name);
  mediaState(next);
  layout();
}

function stopEngine() {
  clearTimeout(connectTimer);
  if (hls) { try { hls.destroy(); } catch { /* */ } hls = null; }
  audio.removeAttribute("src");
  try { audio.load(); } catch { /* */ }
}

function play(s) {
  if (!s) return;
  audioUnlocked = true;
  current = s;
  urls = playUrls(s); urlIndex = 0;
  token++;
  showNowPlaying(s);
  addRecent(s);
  history.replaceState(null, "", `#s=${encodeURIComponent(s.id)}`);
  store.set("last", s.id);
  setState("loading");
  tryUrl(token);
}

function tryUrl(myToken) {
  if (myToken !== token) return;
  stopEngine();
  if (urlIndex >= urls.length) { setState("error"); return; }
  const u = urls[urlIndex];
  const useHls = (current.hls || /\.m3u8(\?|$)/i.test(u));
  if (useHls && window.Hls && window.Hls.isSupported()) {
    hls = new window.Hls({ lowLatencyMode: false, maxBufferLength: 20 });
    hls.on(window.Hls.Events.ERROR, (_, data) => { if (data.fatal && myToken === token) nextUrl(myToken); });
    hls.loadSource(u);
    hls.attachMedia(audio);
  } else {
    audio.src = u;
  }
  audio.volume = IS_NATIVE ? 1 : settings.volume;
  const p = audio.play();
  if (p && p.catch) {
    p.catch((err) => {
      if (myToken !== token) return;
      if (err && err.name === "NotAllowedError") { stopEngine(); setState("paused"); toast(t("tapToPlay")); }
      // other errors arrive through the 'error' event / hls error handler
    });
  }
  connectTimer = setTimeout(() => { if (myToken === token && state === "loading") nextUrl(myToken); }, CFG.connectTimeout * 1000);
}
function nextUrl(myToken) { urlIndex++; tryUrl(myToken); }

audio.addEventListener("playing", () => { clearTimeout(connectTimer); setState("playing"); });
audio.addEventListener("waiting", () => { if (state === "playing") setState("loading", t("buffering")); });
audio.addEventListener("error", () => {
  if (!audio.getAttribute("src") || hls) return;   // our own stopEngine(), or hls handles errors itself
  if (state === "loading" || state === "playing") nextUrl(token);
});
audio.addEventListener("pause", () => {
  // paused by the system (headphones unplugged, phone call, another app took audio focus)
  if (state === "playing" && audio.getAttribute("src")) { token++; clearTimeout(connectTimer); setState("paused"); }
});
audio.addEventListener("ended", () => { if (state === "playing") play(current); });   // some servers drop; reconnect

function pause() {
  token++;                 // cancels pending retries
  stopEngine();            // stop downloading (saves mobile data); resume reconnects to the live edge
  setState("paused");
}
function togglePlay() {
  if (!current) { const s = currentPlace?.stations[0] || STATIONS[0]; if (s) play(s); return; }
  if (state === "playing" || state === "loading") pause(); else play(current);
}
function nextStation(dir = 1) {
  if (!current) return;
  const list = current.place?.stations || [];
  if (list.length > 1) {
    const i = list.indexOf(current);
    play(list[(i + dir + list.length) % list.length]);
    return;
  }
  // only one station here: hop to the nearest other place
  const near = PLACES.filter((p) => p !== current.place)
    .map((p) => [p, haversine(p, current)]).sort((a, b) => a[1] - b[1])[0];
  if (near) { selectPlace(near[0]); flyToPlace(near[0]); play(near[0].stations[0]); }
}

function showNowPlaying(s) {
  $("#player").hidden = false;
  $("#np-name").textContent = s.name;
  $("#np-art").innerHTML = artInner(s);
  $("#np-fav").setAttribute("aria-pressed", String(isFav(s.id)));
  const site = $("#act-site");
  if (s.homepage) { site.href = s.homepage; site.hidden = false; } else site.hidden = true;
  document.title = `${s.name} - ${CFG.appName}`;
  document.querySelectorAll(".station-list li.current").forEach((li) => li.classList.remove("current"));
  document.querySelectorAll(`.station-list li[data-id="${CSS.escape(s.id)}"]`).forEach((li) => li.classList.add("current"));
  mediaMeta(s);
}

/* ------------------------------------------------ lock screen / notification */
function artworkFor(s) {
  return s.favicon ? [{ src: s.favicon, sizes: "256x256" }] : [{ src: new URL("icons/icon-512.png", location.href).href, sizes: "512x512", type: "image/png" }];
}
function mediaMeta(s) {
  const meta = { title: s.name, artist: placeLabel(s), album: CFG.appName, artwork: artworkFor(s) };
  if ("mediaSession" in navigator) { try { navigator.mediaSession.metadata = new MediaMetadata(meta); } catch { /* */ } }
  if (NativeMedia) NativeMedia.setMetadata(meta).catch(() => {});
}
function mediaState(st) {
  const ps = st === "playing" || st === "loading" ? "playing" : st === "paused" ? "paused" : "none";
  if ("mediaSession" in navigator) { try { navigator.mediaSession.playbackState = ps; } catch { /* */ } }
  if (NativeMedia) NativeMedia.setPlaybackState({ playbackState: ps }).catch(() => {});
}
function setupMediaActions() {
  const handlers = {
    play: () => { if (state !== "playing") togglePlay(); },
    pause: () => { if (state === "playing" || state === "loading") pause(); },
    stop: () => pause(),
    nexttrack: () => nextStation(1),
    previoustrack: () => nextStation(-1),
  };
  for (const [action, fn] of Object.entries(handlers)) {
    if ("mediaSession" in navigator) { try { navigator.mediaSession.setActionHandler(action, fn); } catch { /* unsupported action */ } }
    if (NativeMedia) NativeMedia.setActionHandler({ action }, fn).catch(() => {});
  }
}

/* ---------------------------------------------------- saved / recent lists */
const isFav = (id) => favs.some((f) => f.id === id);
const snap = (s) => ({ id: s.id, name: s.name, city: s.city, country: s.country, tags: s.tags || "", favicon: s.favicon || "" });
function toggleFav(s) {
  if (!s) return;
  if (isFav(s.id)) { favs = favs.filter((f) => f.id !== s.id); toast(t("removed1")); }
  else { favs.unshift(snap(s)); toast(t("saved1")); }
  store.set("favs", favs);
  document.querySelectorAll(`li[data-id="${CSS.escape(s.id)}"] .st-fav`).forEach((b) => b.setAttribute("aria-pressed", String(isFav(s.id))));
  if (current && current.id === s.id) $("#np-fav").setAttribute("aria-pressed", String(isFav(s.id)));
  if (!$("#drawer").hidden && activeTab === "saved") renderTab();
}
function addRecent(s) {
  recents = [snap(s), ...recents.filter((r) => r.id !== s.id)].slice(0, 30);
  store.set("recent", recents);
}

/* --------------------------------------------------------------- search */
let activeTab = "search", searchTimer;
function openDrawer(tab) {
  activeTab = tab; $("#drawer").hidden = false; renderTab();
  if (tab === "search") setTimeout(() => $("#q").focus(), 50);
}
function closeDrawer() { $("#drawer").hidden = true; }
function renderTab() {
  document.querySelectorAll(".tabs button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.tab === activeTab)));
  $("#search-box").hidden = activeTab !== "search";
  const ul = $("#results");
  if (activeTab === "saved") renderList(ul, favs, { emptyText: t("emptySaved") });
  else if (activeTab === "recent") renderList(ul, recents, { emptyText: t("emptyRecent") });
  else runSearch();
}
function runSearch() {
  const q = norm($("#q").value.trim());
  const ul = $("#results");
  if (!q) { renderList(ul, [], { emptyText: t("typeToSearch") }); return; }
  const terms = q.split(/\s+/);
  const scored = [];
  for (const s of STATIONS) {
    if (!terms.every((w) => s._q.includes(w))) continue;
    const score = s._n.startsWith(q) ? 3 : s._n.includes(q) ? 2 : 1;
    scored.push([score, s]);
    if (scored.length > 2000) break;
  }
  scored.sort((a, b) => b[0] - a[0]);
  renderList(ul, scored.slice(0, 80).map((x) => x[1]), { emptyText: t("noResults") });
}

/* --------------------------------------------------------- extra actions */
function surprise() {
  const p = PLACES[Math.floor(Math.random() * PLACES.length)]; if (!p) return;
  selectPlace(p); flyToPlace(p, 4); play(p.stations[Math.floor(Math.random() * p.stations.length)]);
}
function nearMe() {
  if (!navigator.geolocation) { toast(t("noLocation")); return; }
  navigator.geolocation.getCurrentPosition((pos) => {
    const me = { lat: pos.coords.latitude, lon: pos.coords.longitude };
    let best = null, bd = Infinity;
    for (const p of PLACES) { const d = haversine(me, p); if (d < bd) { bd = d; best = p; } }
    if (best) { selectPlace(best); flyToPlace(best, 6); }
  }, () => toast(t("noLocation")), { maximumAge: 600000, timeout: 10000 });
}
let sleepTimer = null;
function setSleep(min) {
  clearTimeout(sleepTimer); sleepTimer = null;
  if (!min) return;
  toast(t("sleepSet", min));
  sleepTimer = setTimeout(() => {
    const start = audio.volume; let i = 0;
    const fade = setInterval(() => {
      audio.volume = Math.max(0, start * (1 - ++i / 20));
      if (i >= 20) { clearInterval(fade); pause(); audio.volume = start; $("#set-sleep").value = "0"; toast(t("sleepDone")); }
    }, 500);
  }, min * 60000);
}
async function share() {
  if (!current) return;
  const base = IS_NATIVE ? CFG.siteUrl : location.href.split("#")[0];
  const url = `${base}#s=${encodeURIComponent(current.id)}`;
  try {
    if (navigator.share) await navigator.share({ title: current.name, text: `${current.name} - ${placeLabel(current)}`, url });
    else { await navigator.clipboard.writeText(url); toast(t("linkCopied")); }
  } catch { /* user cancelled */ }
}
function relHours(iso) { return iso ? Math.max(0, Math.round((Date.now() - Date.parse(iso)) / 3600000)) : 0; }
function renderAbout() {
  let txt = t("about", STATIONS.length, t("ago", relHours(META.generated)));
  if (!IS_NATIVE && META.appOnly) txt += t("appOnly", META.appOnly);
  $("#about").textContent = txt;
}

/* ------------------------------------------------------------------ wire */
function wireUI() {
  $("#np-play").addEventListener("click", togglePlay);
  $("#np-next").addEventListener("click", () => nextStation(1));
  $("#np-fav").addEventListener("click", () => toggleFav(current));
  $("#place-list").addEventListener("click", onListClick);
  $("#results").addEventListener("click", onListClick);
  $("#btn-search").addEventListener("click", () => openDrawer("search"));
  $("#btn-saved").addEventListener("click", () => openDrawer("saved"));
  $("#btn-menu").addEventListener("click", () => { renderAbout(); $("#menu").hidden = false; });
  $("#menu-close").addEventListener("click", () => { $("#menu").hidden = true; });
  $("#drawer-close").addEventListener("click", closeDrawer);
  $("#drawer").addEventListener("click", (e) => { if (e.target.id === "drawer") closeDrawer(); });
  $("#menu").addEventListener("click", (e) => { if (e.target.id === "menu") $("#menu").hidden = true; });
  document.querySelectorAll(".tabs button").forEach((b) => b.addEventListener("click", () => { activeTab = b.dataset.tab; renderTab(); }));
  $("#q").addEventListener("input", () => { clearTimeout(searchTimer); searchTimer = setTimeout(runSearch, 120); });
  $("#btn-random").addEventListener("click", surprise);
  $("#btn-locate").addEventListener("click", nearMe);
  $("#grabber").addEventListener("click", () => toggleSheet());
  $("#grabber").addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggleSheet(); } });
  let y0 = null;
  $("#sheet").addEventListener("touchstart", (e) => { if (e.target.closest(".grabber, .place-head, #player")) y0 = e.touches[0].clientY; }, { passive: true });
  $("#sheet").addEventListener("touchend", (e) => {
    if (y0 == null) return; const dy = e.changedTouches[0].clientY - y0; y0 = null;
    if (dy < -40) toggleSheet(false); else if (dy > 40) toggleSheet(true);
  });

  const lang = $("#set-lang"), auto = $("#set-autoplay"), vol = $("#set-volume");
  lang.value = settings.lang; auto.checked = settings.autoplay; vol.value = settings.volume;
  lang.addEventListener("change", () => {
    settings.lang = lang.value; saveSettings(); applyI18n(); renderAbout();
    if (currentPlace) selectPlace(currentPlace); if (current) setState(state);
  });
  auto.addEventListener("change", () => { settings.autoplay = auto.checked; saveSettings(); });
  vol.addEventListener("input", () => { settings.volume = +vol.value; audio.volume = settings.volume; saveSettings(); });
  if (IS_NATIVE || matchMedia("(pointer: coarse)").matches) $("#volume-row").hidden = true;
  $("#set-sleep").addEventListener("change", (e) => setSleep(+e.target.value));
  $("#act-share").addEventListener("click", share);

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { closeDrawer(); $("#menu").hidden = true; return; }
    if (e.target.closest("input, select, textarea")) return;
    if (e.key === " ") { e.preventDefault(); togglePlay(); }
    else if (e.key === "/") { e.preventDefault(); openDrawer("search"); }
    else if (e.key === "ArrowRight" && e.shiftKey) nextStation(1);
  });
  window.addEventListener("resize", layout);
  window.addEventListener("hashchange", () => openFromHash(false));
}

function openFromHash(initial) {
  const m = location.hash.match(/s=([^&]+)/);
  const id = m ? decodeURIComponent(m[1]) : initial ? store.get("last", null) : null;
  const s = id && BY_ID.get(id);
  if (!s) return false;
  selectPlace(s.place);
  map.jumpTo({ center: [s.lon, s.lat], zoom: Math.max(map.getZoom(), 3.5) });
  if (initial) {           // browsers need a tap before audio can start
    current = s; showNowPlaying(s); setState("paused");
  } else play(s);
  return true;
}

async function boot() {
  applyI18n();
  $("#boot-text").textContent = t("loading");
  wireUI();
  try {
    await loadData();
  } catch (e) {
    console.error(e);
    const b = $("#boot"); b.classList.add("failed");
    $("#boot-text").textContent = t("loadFailed");
    const btn = document.createElement("button"); btn.className = "text-btn"; btn.textContent = t("retry");
    btn.onclick = () => location.reload(); b.appendChild(btn);
    return;
  }
  await initMap(CFG.start);
  layout();
  setupMediaActions();
  if (!openFromHash(true)) {
    const p = placeUnderReticle();
    if (p) selectPlace(p);
  }
  renderAbout();
  $("#boot").classList.add("gone");
  if ("serviceWorker" in navigator && !IS_NATIVE && location.protocol === "https:") {
    navigator.serviceWorker.register("sw.js").catch((e) => console.warn("sw:", e));
  }
  if (IS_NATIVE) window.Capacitor.Plugins?.SplashScreen?.hide?.();
}

boot();
// exposed for tests and debugging
window.__th = { get stations() { return STATIONS; }, get places() { return PLACES; }, get state() { return state; }, get current() { return current; }, play, pause, selectPlace };
