// Edit these for your deployment.
window.THARANGAM_CONFIG = {
  appName: "Tharangam",

  // Where the station list lives. The website uses the relative path.
  // The Android app loads the same file from your live site so it gets the
  // twice-daily updates without an app update, and falls back to the copy
  // bundled inside the app if the network is down.
  dataUrl: "data/stations.json",
  remoteDataUrl: "https://YOUR-GITHUB-USERNAME.github.io/tharangam-radio/data/stations.json",

  // Public site address, used for share links from inside the app.
  siteUrl: "https://YOUR-GITHUB-USERNAME.github.io/tharangam-radio/",

  // Optional detailed map (city names, lakes) from OpenFreeMap - free, no key.
  // The basic globe is bundled and works offline either way.
  detailTiles: true,

  // Where the globe starts if we have nothing better (Kerala).
  start: { lon: 76.3, lat: 10.0, zoom: 2.2 },

  // Seconds to wait for a stream before showing "couldn't connect".
  connectTimeout: 15,
};
