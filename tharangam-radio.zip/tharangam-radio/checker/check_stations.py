#!/usr/bin/env python3
"""
Tharangam Radio - station health checker.

Runs twice a day (GitHub Actions cron). For every station it:
  1. Opens the stream and reads the first few KB (handles plain HTTP, ICY/Shoutcast,
     redirects, .pls/.m3u playlists and HLS .m3u8).
  2. Rejects "fake alive" links (HTML error pages that return 200, empty bodies).
  3. Tries an https:// version of http:// links, because https websites cannot play
     http streams (browser mixed-content block).

Rules
  * A station that fails a check (after in-run retries) is HIDDEN from the site/app
    until it passes again.
  * A station that has failed continuously for REMOVE_AFTER_HOURS (default 72h = 3 days)
    and at least MIN_FAILS_TO_REMOVE checks is REMOVED (moved to the graveyard).
  * Graveyard stations are re-probed weekly; if one comes back it is restored.
  * Safety valve: if more than MAX_FAIL_RATIO of stations fail in one run, the run is
    treated as a network problem on the checker side and failures are NOT counted.

No third-party packages: Python 3.10+ standard library only.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import hashlib
import http.client
import json
import os
import random
import socket
import ssl
import sys
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone

APP_NAME = "TharangamRadio"
APP_VERSION = "1.0"
USER_AGENT = f"{APP_NAME}/{APP_VERSION} (station-checker)"

REMOVE_AFTER_HOURS = 72
MIN_FAILS_TO_REMOVE = 5          # 3 days x 2 checks/day = 6; 5 tolerates one missed run
GRAVEYARD_RECHECK_DAYS = 7
GRAVEYARD_PURGE_DAYS = 90
MAX_FAIL_RATIO = 0.5             # safety valve
RETRIES = 2                      # extra attempts inside one run before counting a failure
CONNECT_TIMEOUT = 8
READ_TIMEOUT = 10
MIN_AUDIO_BYTES = 2048
MAX_REDIRECTS = 5

AUDIO_TYPES = ("audio/", "application/ogg", "video/mp2t", "application/octet-stream",
               "audio/aacp", "video/mp4")
HLS_TYPES = ("application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl",
             "audio/x-mpegurl")
PLS_TYPES = ("audio/x-scpls", "application/pls+xml", "audio/scpls")

_SSL_CTX = ssl.create_default_context()
_sleep = time.sleep  # indirection so tests can skip retry back-off


def now_ts() -> float:
    return time.time()


def iso(ts: float | None) -> str | None:
    if ts is None:
        return None
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------------------------
# Probing
# --------------------------------------------------------------------------------------
@dataclass
class ProbeResult:
    ok: bool
    error: str = ""
    final_url: str = ""
    content_type: str = ""
    hls: bool = False
    status: int = 0


class _ICYResponse(Exception):
    """Raised when a server answers 'ICY 200 OK' (old Shoutcast), which http.client rejects."""


def _open(url: str):
    """Open url and return (status, headers(dict, lower-case), first_bytes, location)."""
    parts = urllib.parse.urlsplit(url)
    if parts.scheme not in ("http", "https"):
        raise ValueError(f"unsupported scheme {parts.scheme!r}")
    host = parts.hostname
    if not host:
        raise ValueError("no host")
    port = parts.port or (443 if parts.scheme == "https" else 80)
    path = parts.path or "/"
    if parts.query:
        path += "?" + parts.query

    if parts.scheme == "https":
        conn = http.client.HTTPSConnection(host, port, timeout=CONNECT_TIMEOUT, context=_SSL_CTX)
    else:
        conn = http.client.HTTPConnection(host, port, timeout=CONNECT_TIMEOUT)
    try:
        conn.putrequest("GET", path, skip_accept_encoding=True)
        conn.putheader("User-Agent", USER_AGENT)
        conn.putheader("Accept", "*/*")
        conn.putheader("Icy-MetaData", "0")
        conn.putheader("Connection", "close")
        conn.endheaders()
        try:
            resp = conn.getresponse()
        except http.client.BadStatusLine as e:
            line = str(e.args[0] if e.args else "")
            if line.upper().startswith("ICY"):
                raise _ICYResponse(line) from None
            raise
        if conn.sock:
            conn.sock.settimeout(READ_TIMEOUT)
        headers = {k.lower(): v for k, v in resp.getheaders()}
        body = b""
        if 200 <= resp.status < 300:
            deadline = time.monotonic() + READ_TIMEOUT
            while len(body) < MIN_AUDIO_BYTES * 2 and time.monotonic() < deadline:
                chunk = resp.read1(8192) if hasattr(resp, "read1") else resp.read(8192)
                if not chunk:
                    break
                body += chunk
        return resp.status, headers, body, headers.get("location")
    finally:
        conn.close()


def _open_raw_icy(url: str):
    """Fallback for 'ICY 200 OK' servers: speak HTTP over a raw socket."""
    parts = urllib.parse.urlsplit(url)
    port = parts.port or (443 if parts.scheme == "https" else 80)
    path = (parts.path or "/") + (("?" + parts.query) if parts.query else "")
    sock = socket.create_connection((parts.hostname, port), timeout=CONNECT_TIMEOUT)
    try:
        if parts.scheme == "https":
            sock = _SSL_CTX.wrap_socket(sock, server_hostname=parts.hostname)
        sock.settimeout(READ_TIMEOUT)
        req = (f"GET {path} HTTP/1.0\r\nHost: {parts.hostname}\r\nUser-Agent: {USER_AGENT}\r\n"
               f"Icy-MetaData: 0\r\nAccept: */*\r\n\r\n").encode()
        sock.sendall(req)
        data = b""
        deadline = time.monotonic() + READ_TIMEOUT
        while len(data) < MIN_AUDIO_BYTES * 2 + 4096 and time.monotonic() < deadline:
            chunk = sock.recv(8192)
            if not chunk:
                break
            data += chunk
    finally:
        sock.close()
    head, _, body = data.partition(b"\r\n\r\n")
    lines = head.decode("latin-1", "replace").split("\r\n")
    status_line = lines[0] if lines else ""
    headers = {}
    for ln in lines[1:]:
        if ":" in ln:
            k, v = ln.split(":", 1)
            headers[k.strip().lower()] = v.strip()
    status = 200 if " 200" in status_line else 0
    return status, headers, body, None


def _parse_playlist(text: str, base_url: str) -> list[str]:
    urls = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("["):
            continue
        if line.lower().startswith("file") and "=" in line:      # .pls
            line = line.split("=", 1)[1].strip()
        elif "=" in line and not line.lower().startswith("http"):
            continue
        if line.lower().startswith(("http://", "https://")):
            urls.append(line)
        elif not line.lower().startswith(("title", "length", "numberofentries", "version")):
            urls.append(urllib.parse.urljoin(base_url, line))
    return urls


def _looks_like_html(body: bytes, ctype: str) -> bool:
    if "text/html" in ctype or "application/xhtml" in ctype:
        return True
    head = body[:512].lstrip().lower()
    return head.startswith((b"<!doctype", b"<html", b"<?xml", b"<head", b"<body"))


def probe(url: str, depth: int = 0) -> ProbeResult:
    """Return whether `url` delivers playable audio right now."""
    if depth > 2:
        return ProbeResult(False, "playlist nesting too deep")
    current = url
    try:
        for _ in range(MAX_REDIRECTS + 1):
            try:
                status, headers, body, location = _open(current)
            except _ICYResponse:
                status, headers, body, location = _open_raw_icy(current)
                headers.setdefault("content-type", "audio/mpeg")
            if status in (301, 302, 303, 307, 308) and location:
                current = urllib.parse.urljoin(current, location)
                continue
            break
        else:
            return ProbeResult(False, "too many redirects", current)

        if not 200 <= status < 300:
            return ProbeResult(False, f"HTTP {status}", current, status=status)

        ctype = headers.get("content-type", "").split(";")[0].strip().lower()
        lower_url = current.lower().split("?")[0]
        text_head = body[:2048].decode("utf-8", "ignore")

        # HLS (.m3u8) - must contain HLS tags; a plain .m3u falls through to playlist handling
        if "#EXT-X-" in text_head or (lower_url.endswith(".m3u8") and "#EXTM3U" in text_head):
            if "#EXTINF" in text_head or "#EXT-X-STREAM-INF" in text_head or "#EXT-X-TARGETDURATION" in text_head:
                return ProbeResult(True, "", current, ctype or "application/vnd.apple.mpegurl", hls=True, status=status)
            return ProbeResult(False, "empty HLS playlist", current, ctype, status=status)

        # Classic playlists (.pls / .m3u) -> resolve and probe the first stream inside
        if ctype in PLS_TYPES or ctype in HLS_TYPES or lower_url.endswith((".pls", ".m3u")) or \
                text_head.lstrip().lower().startswith(("[playlist]", "#extm3u")):
            for inner in _parse_playlist(text_head, current)[:3]:
                r = probe(inner, depth + 1)
                if r.ok:
                    return r
            return ProbeResult(False, "playlist has no working stream", current, ctype, status=status)

        if _looks_like_html(body, ctype):
            return ProbeResult(False, "returns a web page, not audio", current, ctype, status=status)

        is_audio_type = ctype.startswith(AUDIO_TYPES) or any(k.startswith("icy-") for k in headers)
        if not is_audio_type and ctype:
            return ProbeResult(False, f"unexpected content-type {ctype}", current, ctype, status=status)
        if len(body) < MIN_AUDIO_BYTES:
            return ProbeResult(False, f"stream sent only {len(body)} bytes", current, ctype, status=status)
        return ProbeResult(True, "", current, ctype or "audio/mpeg", status=status)

    except ssl.SSLError as e:
        return ProbeResult(False, f"TLS error: {e.reason or e}", current)
    except (socket.timeout, TimeoutError):
        return ProbeResult(False, "timeout", current)
    except (ConnectionError, OSError) as e:
        return ProbeResult(False, f"connection error: {e.__class__.__name__}", current)
    except (http.client.HTTPException, ValueError) as e:
        return ProbeResult(False, f"{e.__class__.__name__}: {e}"[:120], current)


def probe_with_retries(url: str, retries: int = RETRIES) -> ProbeResult:
    r = probe(url)
    for attempt in range(retries):
        if r.ok:
            break
        if r.status in (404, 410):          # definitive, don't waste time
            break
        _sleep(1.5 * (attempt + 1))
        r = probe(url)
    return r


def check_station(st: dict) -> dict:
    """Probe a station. Returns dict(ok, error, play_url, https_url, hls, codec_type)."""
    url = st["url"]
    r = probe_with_retries(url)
    out = {"ok": r.ok, "error": r.error, "play_url": None, "https_url": None, "hls": r.hls}
    if not r.ok:
        return out
    out["play_url"] = r.final_url or url
    if out["play_url"].startswith("https://"):
        out["https_url"] = out["play_url"]
    else:
        # https sites can only play https streams -> try an upgraded URL
        for candidate in _https_candidates(out["play_url"]):
            rs = probe(candidate)
            if rs.ok:
                out["https_url"] = rs.final_url or candidate
                break
    return out


def _https_candidates(http_url: str) -> list[str]:
    p = urllib.parse.urlsplit(http_url)
    cands = []
    if p.port in (None, 80):
        cands.append(urllib.parse.urlunsplit(("https", p.hostname, p.path, p.query, "")))
    else:
        cands.append(urllib.parse.urlunsplit(("https", p.netloc, p.path, p.query, "")))
    return cands


# --------------------------------------------------------------------------------------
# Sources
# --------------------------------------------------------------------------------------
def http_json(url: str, timeout: int = 60):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def radio_browser_servers() -> list[str]:
    try:
        servers = http_json("https://all.api.radio-browser.info/json/servers", timeout=20)
        names = sorted({s["name"] for s in servers if s.get("name")})
        random.shuffle(names)
        if names:
            return [f"https://{n}" for n in names]
    except Exception as e:  # noqa: BLE001
        print(f"  ! server discovery failed: {e}", file=sys.stderr)
    return ["https://de1.api.radio-browser.info", "https://fi1.api.radio-browser.info",
            "https://de2.api.radio-browser.info"]


def fetch_radio_browser(limit: int) -> list[dict]:
    """Popular stations that have map coordinates and pass radio-browser's own checks."""
    q = urllib.parse.urlencode({
        "has_geo_info": "true", "hidebroken": "true", "order": "clickcount",
        "reverse": "true", "limit": str(limit),
    })
    last_err = None
    for base in radio_browser_servers():
        try:
            rows = http_json(f"{base}/json/stations/search?{q}", timeout=120)
            print(f"  radio-browser: {len(rows)} stations from {base}")
            return [normalize_rb(r) for r in rows if r.get("url_resolved") or r.get("url")]
        except Exception as e:  # noqa: BLE001
            last_err = e
            print(f"  ! {base} failed: {e}", file=sys.stderr)
    raise RuntimeError(f"all radio-browser servers failed: {last_err}")


def _clean(s) -> str:
    return " ".join(str(s or "").split())[:120]


def normalize_rb(r: dict) -> dict:
    url = (r.get("url_resolved") or r.get("url") or "").strip()
    tags = [t.strip().lower() for t in (r.get("tags") or "").split(",") if t.strip()][:6]
    return {
        "id": "rb:" + r["stationuuid"],
        "name": _clean(r.get("name")),
        "url": url,
        "homepage": (r.get("homepage") or "").strip()[:300],
        "favicon": (r.get("favicon") or "").strip()[:300],
        "country": _clean(r.get("country")),
        "cc": (r.get("countrycode") or "").upper()[:2],
        "city": _clean(r.get("state")),
        "lat": r.get("geo_lat"),
        "lon": r.get("geo_long"),
        "tags": tags,
        "lang": _clean(r.get("language"))[:60],
        "codec": (r.get("codec") or "")[:12],
        "bitrate": int(r.get("bitrate") or 0),
        "votes": int(r.get("votes") or 0),
        "source": "radio-browser",
        "rb_ok": int(r.get("lastcheckok") or 0),
    }


def load_custom(path: str) -> list[dict]:
    """Your own hand-picked stations (always kept, take priority over radio-browser)."""
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        rows = json.load(f)
    out = []
    for r in rows:
        if not (r.get("name") and r.get("url") and r.get("lat") is not None and r.get("lon") is not None):
            print(f"  ! custom station skipped (needs name, url, lat, lon): {r}", file=sys.stderr)
            continue
        sid = r.get("id") or "c:" + hashlib.sha1(r["url"].encode()).hexdigest()[:12]
        out.append({
            "id": sid, "name": _clean(r["name"]), "url": r["url"].strip(),
            "homepage": r.get("homepage", ""), "favicon": r.get("favicon", ""),
            "country": _clean(r.get("country")), "cc": (r.get("cc") or "").upper()[:2],
            "city": _clean(r.get("city")), "lat": r["lat"], "lon": r["lon"],
            "tags": [t.lower() for t in r.get("tags", [])][:6], "lang": _clean(r.get("lang")),
            "codec": r.get("codec", ""), "bitrate": int(r.get("bitrate") or 0),
            "votes": 10**6, "source": "custom", "featured": bool(r.get("featured")),
        })
    return out


# --------------------------------------------------------------------------------------
# State handling
# --------------------------------------------------------------------------------------
def load_state(path: str) -> dict:
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            st = json.load(f)
        st.setdefault("stations", {})
        st.setdefault("graveyard", {})
        st.setdefault("runs", [])
        return st
    return {"stations": {}, "graveyard": {}, "runs": []}


def save_json_atomic(path: str, data, compact: bool = False):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        if compact:
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
        else:
            json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def valid_coords(s: dict) -> bool:
    try:
        lat, lon = float(s["lat"]), float(s["lon"])
    except (TypeError, ValueError, KeyError):
        return False
    return -90 <= lat <= 90 and -180 <= lon <= 180 and not (lat == 0 and lon == 0)


def merge_sources(state: dict, incoming: list[dict], ts: float) -> int:
    """Add new stations / refresh metadata. Graveyard stations are not re-added."""
    added = 0
    seen_urls = {s["url"] for s in state["stations"].values()}
    for s in incoming:
        if not s["url"].lower().startswith(("http://", "https://")) or not valid_coords(s):
            continue
        sid = s["id"]
        if sid in state["graveyard"]:
            continue
        cur = state["stations"].get(sid)
        if cur:
            keep = {k: cur[k] for k in ("first_seen", "last_ok", "last_checked", "fail_streak",
                                        "first_fail", "last_error", "play_url", "https_url",
                                        "hls", "hidden") if k in cur}
            cur.update(s)
            cur.update(keep)
        else:
            if s["url"] in seen_urls:       # duplicate stream under another id
                continue
            s.update({"first_seen": ts, "last_ok": None, "last_checked": None, "fail_streak": 0,
                      "first_fail": None, "last_error": "", "hidden": True})
            state["stations"][sid] = s
            seen_urls.add(s["url"])
            added += 1
    return added


def apply_result(s: dict, res: dict, ts: float, count_failures: bool, rb_says_ok: bool):
    s["last_checked"] = ts
    if res["ok"]:
        s.update(last_ok=ts, fail_streak=0, first_fail=None, last_error="", hidden=False,
                 play_url=res["play_url"], https_url=res["https_url"], hls=res["hls"])
        return
    s["last_error"] = res["error"]
    if not count_failures:
        return
    if rb_says_ok:
        # Our checker (one location) failed but radio-browser's checkers say it works.
        # Usually geo-blocking. Keep it, but don't reset its fail history.
        s["last_error"] += " (radio-browser reports OK - possibly geo-restricted)"
        return
    s["fail_streak"] = int(s.get("fail_streak") or 0) + 1
    if not s.get("first_fail"):
        s["first_fail"] = ts
    s["hidden"] = True


def should_remove(s: dict, ts: float) -> bool:
    if s.get("source") == "custom" and s.get("featured"):
        return False if not s.get("first_fail") else (ts - s["first_fail"]) >= REMOVE_AFTER_HOURS * 3600 * 2
    if not s.get("first_fail"):
        return False
    return (ts - s["first_fail"]) >= REMOVE_AFTER_HOURS * 3600 and \
        int(s.get("fail_streak") or 0) >= MIN_FAILS_TO_REMOVE


# --------------------------------------------------------------------------------------
# Export for the website / app
# --------------------------------------------------------------------------------------
EXPORT_FIELDS = ["id", "name", "url", "https", "lat", "lon", "cc", "country", "city",
                 "tags", "codec", "bitrate", "favicon", "homepage", "hls", "lang", "featured"]


def export_public(state: dict, out_dir: str, ts: float, run_info: dict):
    rows = []
    for s in sorted(state["stations"].values(), key=lambda x: -int(x.get("votes") or 0)):
        if s.get("hidden") or not s.get("play_url"):
            continue
        play = s["play_url"]
        rows.append([
            s["id"], s["name"], play, s.get("https_url") or "",
            round(float(s["lat"]), 4), round(float(s["lon"]), 4),
            s.get("cc", ""), s.get("country", ""), s.get("city", ""),
            ",".join(s.get("tags", [])), s.get("codec", ""), int(s.get("bitrate") or 0),
            s.get("favicon", ""), s.get("homepage", ""), 1 if s.get("hls") else 0,
            s.get("lang", ""), 1 if s.get("featured") else 0,
        ])
    payload = {"v": 1, "generated": iso(ts), "fields": EXPORT_FIELDS, "stations": rows}
    save_json_atomic(os.path.join(out_dir, "stations.json"), payload, compact=True)
    meta = {"generated": iso(ts), "count": len(rows),
            "https_count": sum(1 for r in rows if r[3]), **run_info}
    save_json_atomic(os.path.join(out_dir, "meta.json"), meta)
    return len(rows)


# --------------------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------------------
def run(args) -> int:
    ts = args.now if args.now is not None else now_ts()
    state = load_state(args.state)
    print(f"[{iso(ts)}] {len(state['stations'])} stations in state, {len(state['graveyard'])} in graveyard")

    incoming = load_custom(args.custom)
    if args.seed_limit > 0:
        try:
            incoming += fetch_radio_browser(args.seed_limit)
        except Exception as e:  # noqa: BLE001
            print(f"  ! seeding skipped: {e}", file=sys.stderr)
    if args.seed_file:
        with open(args.seed_file, encoding="utf-8") as f:
            incoming += json.load(f)
    rb_ok = {s["id"]: bool(s.get("rb_ok")) for s in incoming if s.get("source") == "radio-browser"}
    added = merge_sources(state, incoming, ts)
    print(f"  merged sources: +{added} new")

    if args.export_only:
        n = export_public(state, args.out, ts, {"mode": "export-only"})
        save_json_atomic(args.state, state)
        print(f"  exported {n} stations (no probing)")
        return 0

    # Graveyard stations due for a weekly re-check
    due_grave = [g for g in state["graveyard"].values()
                 if ts - (g.get("last_checked") or 0) >= GRAVEYARD_RECHECK_DAYS * 86400]
    targets = list(state["stations"].values())
    print(f"  probing {len(targets)} stations + {len(due_grave)} graveyard re-checks "
          f"with {args.workers} workers...")

    t0 = time.monotonic()
    results: dict[str, dict] = {}
    with cf.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futs = {pool.submit(check_station, s): s["id"] for s in targets + due_grave}
        for i, fut in enumerate(cf.as_completed(futs), 1):
            sid = futs[fut]
            try:
                results[sid] = fut.result()
            except Exception as e:  # noqa: BLE001
                results[sid] = {"ok": False, "error": f"checker crash: {e}"[:120]}
            if i % 500 == 0:
                print(f"    {i}/{len(futs)} done")
    elapsed = time.monotonic() - t0

    live_ids = [s["id"] for s in targets]
    fails = sum(1 for sid in live_ids if not results[sid]["ok"])
    fail_ratio = fails / max(1, len(live_ids))
    count_failures = not (len(live_ids) >= 20 and fail_ratio > MAX_FAIL_RATIO)
    if not count_failures:
        print(f"  !!! SAFETY VALVE: {fail_ratio:.0%} failed - assuming checker network problem; "
              f"failures NOT counted this run", file=sys.stderr)

    removed, restored = [], []
    for s in targets:
        apply_result(s, results[s["id"]], ts, count_failures, args.trust_rb and rb_ok.get(s["id"], False))
        if count_failures and should_remove(s, ts):
            s["removed_at"] = ts
            s["removed_reason"] = s.get("last_error", "")
            state["graveyard"][s["id"]] = s
            del state["stations"][s["id"]]
            removed.append(s)
    for g in due_grave:
        g["last_checked"] = ts
        res = results[g["id"]]
        if res["ok"]:
            g.pop("removed_at", None)
            g.pop("removed_reason", None)
            g.update(fail_streak=0, first_fail=None, hidden=False, last_ok=ts, last_error="",
                     play_url=res["play_url"], https_url=res["https_url"], hls=res["hls"])
            state["stations"][g["id"]] = g
            del state["graveyard"][g["id"]]
            restored.append(g)
    for gid, g in list(state["graveyard"].items()):
        if ts - (g.get("removed_at") or ts) > GRAVEYARD_PURGE_DAYS * 86400:
            del state["graveyard"][gid]

    hidden = sum(1 for s in state["stations"].values() if s.get("hidden"))
    run_info = {
        "checked": len(live_ids), "ok": len(live_ids) - fails, "failed": fails,
        "hidden": hidden, "removed": len(removed), "restored": len(restored),
        "safety_valve": not count_failures, "seconds": round(elapsed, 1),
    }
    state["runs"] = (state["runs"] + [{"at": iso(ts), **run_info}])[-60:]
    n = export_public(state, args.out, ts, run_info)
    save_json_atomic(args.state, state)

    print(f"  done in {elapsed:.0f}s: ok={run_info['ok']} failed={fails} hidden={hidden} "
          f"removed={len(removed)} restored={len(restored)} published={n}")
    for s in removed[:50]:
        print(f"    - removed: {s['name']} ({s.get('last_error')})")
    for s in restored[:50]:
        print(f"    + restored: {s['name']}")

    if args.report:
        with open(args.report, "a", encoding="utf-8") as f:
            f.write(f"## Station check {iso(ts)}\n\n| | |\n|---|---|\n")
            for k, v in run_info.items():
                f.write(f"| {k} | {v} |\n")
            f.write(f"| published | {n} |\n\n")
            if removed:
                f.write("### Removed (dead for 3+ days)\n" +
                        "".join(f"- {s['name']} — {s.get('last_error')}\n" for s in removed[:100]))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--state", default="state/state.json", help="private state file (kept between runs)")
    ap.add_argument("--out", default="web/data", help="where to write public stations.json + meta.json")
    ap.add_argument("--custom", default="checker/custom_stations.json", help="your hand-picked stations")
    ap.add_argument("--seed-limit", type=int, default=12000,
                    help="how many popular stations to pull from radio-browser (0 = none)")
    ap.add_argument("--seed-file", help="extra stations JSON (testing)")
    ap.add_argument("--workers", type=int, default=64)
    ap.add_argument("--export-only", action="store_true", help="rebuild stations.json without probing")
    ap.add_argument("--no-trust-rb", dest="trust_rb", action="store_false",
                    help="don't give radio-browser's 'OK' the benefit of the doubt")
    ap.add_argument("--report", help="append a markdown summary here (e.g. $GITHUB_STEP_SUMMARY)")
    ap.add_argument("--now", type=float, help=argparse.SUPPRESS)  # testing: fake clock
    return run(ap.parse_args(argv))


if __name__ == "__main__":
    sys.exit(main())
