"""
Tests for check_stations.py using local fake radio servers (no internet needed).

    python -m unittest checker/test_checker.py -v
"""
import http.server
import json
import os
import socket
import socketserver
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(__file__))
import check_stations as cs  # noqa: E402

AUDIO = b"\xff\xfb\x90\x64" + os.urandom(16000)
CONTROL = {"outage": False, "toggle": True}


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, *a):
        pass

    def _send(self, code, ctype, body=b"", headers=None):
        self.send_response(code)
        if ctype:
            self.send_header("Content-Type", ctype)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if body:
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def do_GET(self):
        p = self.path.split("?")[0]
        base = f"http://127.0.0.1:{self.server.server_port}"
        if CONTROL["outage"]:
            return self._send(503, "text/plain", b"down")
        if p == "/ok.mp3":
            return self._send(200, "audio/mpeg", AUDIO, {"icy-name": "Test"})
        if p == "/noctype":
            return self._send(200, None, AUDIO, {"icy-br": "128"})
        if p == "/html":
            return self._send(200, "text/html", b"<!DOCTYPE html><html>Station offline</html>")
        if p == "/html-as-audio":
            return self._send(200, "audio/mpeg", b"<html><body>Not found</body></html>" * 100)
        if p == "/redirect":
            return self._send(302, "text/plain", b"", {"Location": "/ok.mp3"})
        if p == "/loop":
            return self._send(302, "text/plain", b"", {"Location": "/loop"})
        if p == "/empty":
            return self._send(200, "audio/mpeg", b"")
        if p == "/slow":
            time.sleep(3)
            return self._send(200, "audio/mpeg", AUDIO)
        if p == "/list.pls":
            return self._send(200, "audio/x-scpls",
                              f"[playlist]\nNumberOfEntries=1\nFile1={base}/ok.mp3\nTitle1=x\n".encode())
        if p == "/list.m3u":
            return self._send(200, "audio/x-mpegurl", f"#EXTM3U\n#EXTINF:-1,x\n{base}/ok.mp3\n".encode())
        if p == "/dead.pls":
            return self._send(200, "audio/x-scpls", f"[playlist]\nFile1={base}/nope\n".encode())
        if p == "/live.m3u8":
            return self._send(200, "application/vnd.apple.mpegurl",
                              b"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nseg1.aac\n")
        if p == "/toggle":
            if CONTROL["toggle"]:
                return self._send(200, "audio/mpeg", AUDIO)
            return self._send(404, "text/plain", b"gone")
        return self._send(404, "text/plain", b"not found")


class ThreadedServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        pass  # the checker's https-upgrade attempts hit this plain-http server; that's expected


def icy_server():
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", 0))
    srv.listen(16)

    def loop():
        while True:
            try:
                c, _ = srv.accept()
            except OSError:
                return
            try:
                c.recv(4096)
                c.sendall(b"ICY 200 OK\r\nicy-name: Old Shoutcast\r\ncontent-type: audio/mpeg\r\n\r\n" + AUDIO)
            except OSError:
                pass
            finally:
                c.close()
    threading.Thread(target=loop, daemon=True).start()
    return srv


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadedServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()
        cls.base = f"http://127.0.0.1:{cls.httpd.server_port}"
        cls.icy = icy_server()
        cls.icy_url = f"http://127.0.0.1:{cls.icy.getsockname()[1]}/stream"
        cls.patches = [mock.patch.object(cs, "READ_TIMEOUT", 1.5),
                       mock.patch.object(cs, "CONNECT_TIMEOUT", 1.5),
                       mock.patch.object(cs, "_sleep", lambda s: None)]
        for p in cls.patches:
            p.start()

    @classmethod
    def tearDownClass(cls):
        for p in cls.patches:
            p.stop()
        cls.httpd.shutdown()
        cls.icy.close()

    def setUp(self):
        CONTROL.update(outage=False, toggle=True)


class ProbeTests(Base):
    def test_ok_stream(self):
        r = cs.probe(self.base + "/ok.mp3")
        self.assertTrue(r.ok, r.error)

    def test_no_content_type_but_icy_headers(self):
        self.assertTrue(cs.probe(self.base + "/noctype").ok)

    def test_icy_200_shoutcast(self):
        r = cs.probe(self.icy_url)
        self.assertTrue(r.ok, r.error)

    def test_html_page_is_dead(self):
        r = cs.probe(self.base + "/html")
        self.assertFalse(r.ok)
        self.assertIn("web page", r.error)

    def test_html_disguised_as_audio_is_dead(self):
        self.assertFalse(cs.probe(self.base + "/html-as-audio").ok)

    def test_404(self):
        r = cs.probe(self.base + "/missing")
        self.assertFalse(r.ok)
        self.assertEqual(r.error, "HTTP 404")

    def test_redirect_followed(self):
        r = cs.probe(self.base + "/redirect")
        self.assertTrue(r.ok)
        self.assertTrue(r.final_url.endswith("/ok.mp3"))

    def test_redirect_loop(self):
        r = cs.probe(self.base + "/loop")
        self.assertFalse(r.ok)
        self.assertIn("redirect", r.error)

    def test_empty_stream(self):
        self.assertFalse(cs.probe(self.base + "/empty").ok)

    def test_timeout(self):
        r = cs.probe(self.base + "/slow")
        self.assertFalse(r.ok)

    def test_pls_resolved_to_real_stream(self):
        r = cs.probe(self.base + "/list.pls")
        self.assertTrue(r.ok, r.error)
        self.assertTrue(r.final_url.endswith("/ok.mp3"), "browser needs the real stream, not the .pls")

    def test_m3u_resolved(self):
        r = cs.probe(self.base + "/list.m3u")
        self.assertTrue(r.ok, r.error)
        self.assertTrue(r.final_url.endswith("/ok.mp3"))

    def test_pls_pointing_to_dead_stream(self):
        self.assertFalse(cs.probe(self.base + "/dead.pls").ok)

    def test_hls(self):
        r = cs.probe(self.base + "/live.m3u8")
        self.assertTrue(r.ok, r.error)
        self.assertTrue(r.hls)

    def test_connection_refused(self):
        self.assertFalse(cs.probe("http://127.0.0.1:1/x").ok)

    def test_bad_scheme(self):
        self.assertFalse(cs.probe("ftp://example.com/x").ok)


class LifecycleTests(Base):
    """Simulates many twice-daily runs with a fake clock."""

    def setUp(self):
        super().setUp()
        self.tmp = tempfile.mkdtemp()
        self.state = os.path.join(self.tmp, "state.json")
        self.out = os.path.join(self.tmp, "out")
        stations = [
            {"id": "t:good", "name": "Good FM", "url": self.base + "/ok.mp3", "lat": 10.0, "lon": 76.3},
            {"id": "t:toggle", "name": "Toggle FM", "url": self.base + "/toggle", "lat": 9.9, "lon": 76.2},
            {"id": "t:html", "name": "Html FM", "url": self.base + "/html", "lat": 9.0, "lon": 76.0},
            {"id": "t:nogeo", "name": "No Geo", "url": self.base + "/ok.mp3?x", "lat": None, "lon": None},
            {"id": "t:dupe", "name": "Dupe", "url": self.base + "/ok.mp3", "lat": 1, "lon": 1},
        ] + [{"id": f"t:n{i}", "name": f"N{i}", "url": f"{self.base}/ok.mp3?n={i}", "lat": i, "lon": i + 1}
             for i in range(1, 25)]
        self.seed = os.path.join(self.tmp, "seed.json")
        with open(self.seed, "w") as f:
            json.dump(stations, f)
        self.t0 = 1_800_000_000.0

    def run_at(self, hours):
        cs.main(["--state", self.state, "--out", self.out, "--custom", "/nonexistent",
                 "--seed-limit", "0", "--seed-file", self.seed, "--workers", "16",
                 "--now", str(self.t0 + hours * 3600)])
        with open(self.state) as f:
            st = json.load(f)
        with open(os.path.join(self.out, "stations.json")) as f:
            pub = json.load(f)
        return st, {r[0] for r in pub["stations"]}

    def test_full_lifecycle(self):
        st, pub = self.run_at(0)
        self.assertIn("t:good", pub)
        self.assertIn("t:toggle", pub)
        self.assertNotIn("t:html", pub, "never-working station must not be published")
        self.assertNotIn("t:nogeo", st["stations"], "stations without coordinates are skipped")
        self.assertNotIn("t:dupe", st["stations"], "duplicate stream URL is skipped")

        # Station dies. Hidden immediately on the next check.
        CONTROL["toggle"] = False
        st, pub = self.run_at(12)
        self.assertNotIn("t:toggle", pub)
        self.assertIn("t:toggle", st["stations"], "hidden, not removed yet")

        # Comes back after 1 day -> visible again, fail history cleared
        CONTROL["toggle"] = True
        st, pub = self.run_at(24)
        self.assertIn("t:toggle", pub)
        self.assertIsNone(st["stations"]["t:toggle"]["first_fail"])

        # Dies again and stays dead: still kept at 60h, removed once 72h has passed
        CONTROL["toggle"] = False
        for h in (36, 48, 60, 72, 84, 96):
            st, pub = self.run_at(h)
            self.assertNotIn("t:toggle", pub)
            self.assertIn("t:toggle", st["stations"], f"removed too early at +{h - 36}h")
        st, pub = self.run_at(108)            # 72h after the first failure at 36h
        self.assertNotIn("t:toggle", st["stations"])
        self.assertIn("t:toggle", st["graveyard"])
        # Never-working station also goes to the graveyard after 3 days
        self.assertIn("t:html", st["graveyard"])

        # Seeding again must not resurrect a removed station
        st, pub = self.run_at(120)
        self.assertNotIn("t:toggle", st["stations"])

        # It comes back to life -> restored on the weekly graveyard re-check
        CONTROL["toggle"] = True
        st, pub = self.run_at(108 + 7 * 24)
        self.assertIn("t:toggle", pub)
        self.assertNotIn("t:toggle", st["graveyard"])

    def test_safety_valve_on_checker_outage(self):
        self.run_at(0)
        CONTROL["outage"] = True             # everything fails = checker's network is broken
        for h in range(12, 12 * 10, 12):     # 4.5 days of "outage"
            st, pub = self.run_at(h)
        self.assertEqual(st["graveyard"].keys() - {"t:html"}, set(), "nothing removed during outage")
        self.assertTrue(st["runs"][-1]["safety_valve"])
        self.assertIn("t:good", pub, "stations stay published during a checker outage")

    def test_export_format(self):
        self.run_at(0)
        with open(os.path.join(self.out, "stations.json")) as f:
            pub = json.load(f)
        self.assertEqual(pub["fields"], cs.EXPORT_FIELDS)
        for row in pub["stations"]:
            self.assertEqual(len(row), len(cs.EXPORT_FIELDS))
        with open(os.path.join(self.out, "meta.json")) as f:
            meta = json.load(f)
        self.assertEqual(meta["count"], len(pub["stations"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
