package com.tharangam.radio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
