// Copies ../web into ./www for the Android build (the app ships with an offline copy
// of the site; the live station list is still fetched from your website).
import { cpSync, rmSync, existsSync, writeFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const src = resolve(root, "../web");
const dst = resolve(root, "www");
rmSync(dst, { recursive: true, force: true });
cpSync(src, dst, { recursive: true, filter: (p) => !p.endsWith("sw.js") });
if (!existsSync(resolve(dst, "data/stations.json"))) {
  // No local list yet: the app will load it from remoteDataUrl in js/config.js
  writeFileSync(resolve(dst, "data/stations.json"), JSON.stringify({ v: 1, generated: null, fields: [], stations: [] }));
  console.log("note: no web/data/stations.json - the app will rely on remoteDataUrl");
}
console.log("copied web -> www");
